<?php
session_start();
echo $aid = $_SESSION["admin_id"];

?>