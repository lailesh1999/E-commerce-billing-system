
<?php

$hostname = "localhost";
$username = "root";
$password="";
$db="book_store";
$link = mysqli_connect($hostname,$username,$password,$db) or die("error connection db");

?>