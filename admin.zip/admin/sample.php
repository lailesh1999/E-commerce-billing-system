<!DOCTYPE html> 
<html lang="en" dir="ltr"> 
  
<head> 
    <meta charset="utf-8"> 
    <title> 
        How to get values from html input 
        array using JavaScript ? 
    </title> 
</head> 
  
<body style="text-align: center;"> 
      
    <h1 style="color: green;"> 
        GeeksforGeeks 
    </h1> 
  
    <h3 id="po">Input Array Elements</h3> 
    <form class="" action="sample.php" method="post"> 
        <input type="text" name="array[]" value="" /><br> 
        <input type="text" name="array[]" value="" /><br> 
        <input type="text" name="array[]" value="" /><br> 
        <input type="text" name="array[]" value="" /><br> 
        <input type="text" name="array[]" value="" /><br> 
        <button type="button" name="button" onclick="Geeks()"> 
            Submit 
        </button> 
    </form> 
    <br> 
  
    <p id="par"></p> 
  
    <script type="text/javascript"> 
        var k = "The respective values are :"; 
        function Geeks() { 
            var input = document.getElementsByName('array[]'); 
            alert(input);
  
            for (var i = 0; i < input.length; i++) { 
                var a = input[i]; 
                k = k + "array[" + i + "].value= " 
                                   + a.value + " "; 
            } 
  
            document.getElementById("par").innerHTML = k; 
            document.getElementById("po").innerHTML = "Output"; 
        } 
    </script> 
</body> 
  
</html> 